package com.example.oxforddictionary;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
String url;
private TextView textView;
private EditText edit;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textView=findViewById(R.id.textView);
        edit=findViewById(R.id.editText);
    }

    private String dictionaryEntries() {
        final String language = "en-gb";
        final String word = edit.getText().toString();
        final String fields = "definitions";
        final String strictMatch = "false";
        final String word_id = word.toLowerCase();
        return "https://od-api.oxforddictionaries.com:443/api/v2/entries/" + language + "/" + word_id + "?" + "fields=" + fields + "&strictMatch=" + strictMatch;
    }

public void sendRequestOnClick(View v)
{
 DictionaryRequest dR = new DictionaryRequest(this,textView);
 url = dictionaryEntries();
 dR.execute(url);
}

}
